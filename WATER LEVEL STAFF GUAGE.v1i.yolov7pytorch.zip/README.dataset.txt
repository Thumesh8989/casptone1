# WATER LEVEL STAFF GUAGE > 2024-08-18 3:58pm
https://universe.roboflow.com/sree-uzaxo/water-level-staff-guage

Provided by a Roboflow user
License: CC BY 4.0

